#!/usr/bin/env python3
"""Deterministic checks for the manuscript's analytic separating examples."""

import json
import numpy as np


def hermitian(matrix):
    return (matrix + matrix.conj().T) / 2


def matrix_log_pd(matrix):
    values, vectors = np.linalg.eigh(hermitian(matrix))
    if values[0] <= 0:
        raise ValueError("matrix is not positive definite")
    return hermitian((vectors * np.log(values)) @ vectors.conj().T)


def f_even(x):
    return 0.5 * ((1 + x) * np.log1p(x) + (1 - x) * np.log1p(-x))


def k_odd(x):
    return (1 + x) * np.log1p(x) - (1 - x) * np.log1p(-x)


def main():
    a, b = 0.9, 0.4
    radius = np.sqrt(a * a + b * b)
    affine_value = 2 * f_even(a) / 3
    unrestricted_derivative = 2 * b * (np.arctanh(a) / a - 1) / 3
    holevo_minus_affine = 2 * (f_even(radius) - f_even(a) - f_even(b)) / 3

    identity = np.eye(2, dtype=complex)
    sigma_x = np.array([[0, 1], [1, 0]], dtype=complex)
    sigma_y = np.array([[0, -1j], [1j, 0]], dtype=complex)
    sigma_z = np.array([[1, 0], [0, -1]], dtype=complex)
    labels = (-1, 0, 1)
    probability = 1 / 3
    states = {
        s: hermitian((identity + b * sigma_z + s * a * sigma_x) / 2)
        for s in labels
    }
    posteriors = {s: hermitian(identity + s * a * sigma_x) for s in labels}
    coefficient = b * b * (
        1 / (1 - a * a) - np.arctanh(a) / a
    ) / 18
    direction = coefficient * np.kron(sigma_y, sigma_y)

    def two_copy_objective(epsilon):
        value = 0.0
        for s in labels:
            for t in labels:
                posterior = hermitian(
                    np.kron(posteriors[s], posteriors[t])
                    + epsilon * s * t * direction
                )
                value += probability * probability * np.trace(
                    np.kron(states[s], states[t]) @ matrix_log_pd(posterior)
                ).real
        return float(value)

    base = two_copy_objective(0.0)
    samples = []
    for epsilon in (1e-5, 1e-4, 1e-3, 1e-2, 5e-2):
        objective = two_copy_objective(epsilon)
        samples.append({
            "epsilon": epsilon,
            "objective": objective,
            "gain": objective - base,
        })

    trine_parameter = 0.6
    antitrine_advantage = (
        2 * k_odd(trine_parameter / 2) - k_odd(trine_parameter)
    ) / 6

    result = {
        "schema_version": 1,
        "collinear_qubit": {
            "a": a,
            "b": b,
            "U_aff": float(affine_value),
            "unrestricted_path_derivative": float(unrestricted_derivative),
            "Holevo_minus_U_aff": float(holevo_minus_affine),
        },
        "two_copy_witness": {
            "correlation_direction": "sigma_y tensor sigma_y",
            "coefficient": float(coefficient),
            "directional_derivative": float(np.trace(direction @ direction).real),
            "base_value": base,
            "twice_single_U_aff": float(2 * affine_value),
            "samples": samples,
        },
        "noisy_trine": {
            "t": trine_parameter,
            "anti_trine_over_best_PVM": float(antitrine_advantage),
        },
        "checks": {
            "unrestricted_gap_direction_positive": bool(unrestricted_derivative > 0),
            "Holevo_gap_positive": bool(holevo_minus_affine > 0),
            "two_copy_direction_positive": bool(coefficient > 0),
            "all_sampled_two_copy_gains_positive": bool(
                all(sample["gain"] > 0 for sample in samples)
            ),
            "anti_trine_advantage_positive": bool(antitrine_advantage > 0),
        },
    }
    print(json.dumps(result, indent=2))
    if not all(result["checks"].values()):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
