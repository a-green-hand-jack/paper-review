#!/usr/bin/env python3
"""Create a user-facing solver-profile candidate for the PRL main figure."""
from __future__ import annotations

import argparse
import csv
import html
import math
from pathlib import Path
from typing import Any

import numpy as np

METHODS = [
    ("Posterior-spectral + bound", "posterior_gap", "posterior_seconds", "#000000", ""),
    ("Direct POVM", "direct_povm_regret", "direct_povm_seconds", "#CC79A7", "8,5"),
    ("Multistart PVM", "multistart_pvm_regret", "multistart_pvm_seconds", "#009E73", "2,4"),
    ("Helstrom", "helstrom_regret", "helstrom_seconds", "#D55E00", "11,5"),
    ("PGM", "pgm_regret", "pgm_seconds", "#0072B2", "6,4,1.5,4"),
]


def load_rows(path: Path) -> list[dict[str, Any]]:
    rows = []
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            parsed: dict[str, Any] = dict(row)
            for key, value in row.items():
                try:
                    parsed[key] = float(value)
                except (TypeError, ValueError):
                    pass
            rows.append(parsed)
    return rows


def text(x: float, y: float, value: str, css: str = "tick", anchor: str = "middle", rotate: float | None = None) -> str:
    transform = f' transform="rotate({rotate} {x:.2f} {y:.2f})"' if rotate is not None else ""
    return f'<text x="{x:.2f}" y="{y:.2f}" class="{css}" text-anchor="{anchor}"{transform}>{html.escape(value)}</text>'


def line(x1: float, y1: float, x2: float, y2: float, css: str = "axis", extra: str = "") -> str:
    return f'<line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" class="{css}" {extra}/>'


def header(width: int, height: int) -> list[str]:
    return [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="183mm" height="74mm" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        '<style>text{font-family:Helvetica,Arial,sans-serif;fill:#202020}.axis{stroke:#1f2937;stroke-width:1.25}.grid{stroke:#d1d5db;stroke-width:.65}.tick{font-size:12.5px}.label{font-size:14px}.panel{font-size:17px;font-weight:700}.legend{font-size:12.5px}.note{font-size:11px}</style>',
    ]


def curve(points: list[tuple[float, float]], color: str, dash: str) -> str:
    values = " ".join(f"{x:.2f},{y:.2f}" for x, y in points)
    dash_attribute = f' stroke-dasharray="{dash}"' if dash else ""
    return f'<polyline points="{values}" fill="none" stroke="{color}" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"{dash_attribute}/>'


def make_figure(rows: list[dict[str, Any]], output: Path, target: float = 1e-6) -> None:
    width, height = 1120, 455
    left, right, top, bottom, gap = 82, 22, 58, 66, 92
    panel_width = (width - left - right - gap) / 2
    panel_height = height - top - bottom
    left_a = left
    left_b = left + panel_width + gap
    out = header(width, height)
    y_scale = lambda fraction: top + panel_height * (1.0 - fraction)

    # (a) Accuracy profile: fraction meeting each target regret.
    log_eps_min, log_eps_max = -12.0, -1.0
    x_scale_a = lambda epsilon: left_a + panel_width * (math.log10(epsilon) - log_eps_min) / (log_eps_max - log_eps_min)
    out += [
        line(left_a, top, left_a, top + panel_height),
        line(left_a, top + panel_height, left_a + panel_width, top + panel_height),
        text(left_a + 4, top + 20, "a", "panel", "start"),
    ]
    for fraction in (0.0, 0.25, 0.5, 0.75, 1.0):
        y = y_scale(fraction)
        out += [line(left_a, y, left_a + panel_width, y, "grid"), text(left_a - 9, y + 4, f"{100*fraction:.0f}", anchor="end")]
    for exponent in (-12, -9, -6, -3, -1):
        epsilon = 10.0 ** exponent
        x = x_scale_a(epsilon)
        out += [line(x, top, x, top + panel_height, "grid"), text(x, top + panel_height + 21, "10" + str(exponent).translate(str.maketrans("-0123456789", "⁻⁰¹²³⁴⁵⁶⁷⁸⁹")))]
    epsilon_grid = np.logspace(log_eps_min, log_eps_max, 180)
    for label, regret_key, _, color, dash in METHODS:
        regrets = np.maximum(0.0, np.array([float(row[regret_key]) for row in rows]))
        points = [(x_scale_a(epsilon), y_scale(float(np.mean(regrets <= epsilon)))) for epsilon in epsilon_grid]
        out.append(curve(points, color, dash))
    out += [
        text(left_a + panel_width / 2, height - 16, "Target regret, ε (nat)", "label"),
        text(19, top + panel_height / 2, "Stress cases meeting target (%)", "label", rotate=-90),
    ]

    # (b) Time-to-accuracy data profile.
    log_time_min, log_time_max = -2.0, 4.2  # milliseconds
    x_scale_b = lambda milliseconds: left_b + panel_width * (math.log10(milliseconds) - log_time_min) / (log_time_max - log_time_min)
    out += [
        line(left_b, top, left_b, top + panel_height),
        line(left_b, top + panel_height, left_b + panel_width, top + panel_height),
        text(left_b + 4, top + 20, "b", "panel", "start"),
    ]
    for fraction in (0.0, 0.25, 0.5, 0.75, 1.0):
        y = y_scale(fraction)
        out += [line(left_b, y, left_b + panel_width, y, "grid"), text(left_b - 9, y + 4, f"{100*fraction:.0f}", anchor="end")]
    time_ticks = [(0.01, "0.01"), (0.1, "0.1"), (1.0, "1"), (10.0, "10"), (100.0, "100"), (1000.0, "1000"), (10000.0, "10⁴")]
    for milliseconds, label in time_ticks:
        x = x_scale_b(milliseconds)
        out += [line(x, top, x, top + panel_height, "grid"), text(x, top + panel_height + 21, label)]
    time_grid = np.logspace(log_time_min, log_time_max, 180)
    for label, regret_key, time_key, color, dash in METHODS:
        regrets = np.maximum(0.0, np.array([float(row[regret_key]) for row in rows]))
        times_ms = 1000.0 * np.array([float(row[time_key]) for row in rows])
        points = [
            (x_scale_b(milliseconds), y_scale(float(np.mean((regrets <= target) & (times_ms <= milliseconds)))))
            for milliseconds in time_grid
        ]
        out.append(curve(points, color, dash))
    out += [
        text(left_b + panel_width / 2, height - 16, "Time budget per ensemble (ms)", "label"),
        text(left_b - 55, top + panel_height / 2, "Cases solved to ε ≤ 10⁻⁶ nat (%)", "label", rotate=-90),
    ]

    legend_widths = [230, 150, 170, 125, 75]
    legend_x = (width - sum(legend_widths)) / 2
    legend_y = 25
    cursor = legend_x
    for item_width, (label, _, _, color, dash) in zip(legend_widths, METHODS):
        dash_attribute = f' stroke-dasharray="{dash}"' if dash else ""
        out.append(f'<line x1="{cursor:.2f}" y1="{legend_y}" x2="{cursor+31:.2f}" y2="{legend_y}" stroke="{color}" stroke-width="2.8" stroke-linecap="round"{dash_attribute}/>')
        out.append(text(cursor + 40, legend_y + 4, label, "legend", "start"))
        cursor += item_width
    out.append("</svg>")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(out), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv", type=Path)
    parser.add_argument("--output", type=Path, default=Path("research/figures/binary_solver_profile.svg"))
    parser.add_argument("--target", type=float, default=1e-6)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    make_figure(load_rows(args.csv), args.output, target=args.target)
    print(f"Wrote {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
