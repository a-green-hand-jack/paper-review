# Executable checks

This directory contains deterministic checks and the machine-readable records
used for the benchmark figure and reported performance claims.

Included in the arXiv source archive:

- `posterior_examples.py` and `finite_iterate_transport.py`: theorem-oriented
  deterministic checks, with reference outputs under `expected/`;
- `binary_stress_benchmark.csv`: the authoritative 408-instance record;
- `binary_stress_benchmark_summary.json`: independently aggregated benchmark
  statistics;
- `plot_binary_solver_profile.py`: dependency-light SVG generator for the
  benchmark figure.

Requirements:

- Python 3
- NumPy

Run from this directory:

    python3 posterior_examples.py
    python3 finite_iterate_transport.py
    python3 plot_binary_solver_profile.py binary_stress_benchmark.csv --output binary_solver_profile.svg

The two theorem-checking scripts print JSON to standard output. Reference
outputs generated for the arXiv release are stored in expected/. The
finite-iterate test uses the fixed seed 20260809 and exits nonzero if either
transport inequality fails.

The released CSV, rather than a timed rerun on different hardware, is the
authoritative benchmark record. These files are verification aids; the
theorems and strict inequalities in the article are proved analytically and do
not rely on floating-point output.
