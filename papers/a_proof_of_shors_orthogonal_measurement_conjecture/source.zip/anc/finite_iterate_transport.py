#!/usr/bin/env python3
"""Monte Carlo corruption test for the finite-iterate transport bounds."""

import json
import numpy as np

RNG = np.random.default_rng(20260809)


def hermitian(matrix):
    return (matrix + matrix.conj().T) / 2


def random_unitary(dimension):
    matrix = (
        RNG.normal(size=(dimension, dimension))
        + 1j * RNG.normal(size=(dimension, dimension))
    )
    unitary, triangular = np.linalg.qr(matrix)
    diagonal = np.diag(triangular)
    phases = np.where(np.abs(diagonal) > 0, diagonal / np.abs(diagonal), 1)
    return unitary * phases.conj()


def run(trials=20000):
    q_failures = delta_failures = 0
    q_min_slack = delta_min_slack = float("inf")
    for _ in range(trials):
        dimension = int(RNG.integers(2, 7))
        count = int(RNG.integers(2, 6))
        weights = RNG.uniform(0.01, 2, count)
        common_basis = random_unitary(dimension)
        exact, approximate = [], []
        for _ in range(count):
            values = RNG.uniform(0.2, 3, dimension)
            matrix = common_basis @ np.diag(values) @ common_basis.conj().T
            error = (
                RNG.normal(size=(dimension, dimension))
                + 1j * RNG.normal(size=(dimension, dimension))
            )
            error = hermitian(error)
            error *= RNG.uniform(0, 0.2) / (np.linalg.norm(error, "fro") + 1e-15)
            exact.append(hermitian(matrix))
            approximate.append(hermitian(matrix + error))

        trial_basis = random_unitary(dimension)

        def off_diagonal(matrix):
            transformed = trial_basis.conj().T @ matrix @ trial_basis
            return transformed - np.diag(np.diag(transformed))

        q_exact = sum(
            weights[i] * np.linalg.norm(off_diagonal(exact[i]), "fro") ** 2
            for i in range(count)
        )
        q_approximate = sum(
            weights[i] * np.linalg.norm(off_diagonal(approximate[i]), "fro") ** 2
            for i in range(count)
        )
        eta = np.sqrt(sum(
            weights[i] * np.linalg.norm(exact[i] - approximate[i], "fro") ** 2
            for i in range(count)
        ))
        q_upper = (np.sqrt(q_approximate) + eta) ** 2
        q_min_slack = min(q_min_slack, q_upper - q_exact)
        if q_exact > q_upper + 1e-9:
            q_failures += 1

        exact_vectors, approximate_vectors = [], []
        for atom in range(dimension):
            projector = np.outer(
                trial_basis[:, atom], trial_basis[:, atom].conj()
            )
            exact_vectors.append(np.array([
                np.trace(projector @ exact[i]).real for i in range(count)
            ]))
            approximate_vectors.append(np.array([
                np.trace(projector @ approximate[i]).real for i in range(count)
            ]))
        delta_exact = min(
            np.sqrt(np.sum(
                weights * (exact_vectors[z] - exact_vectors[z_prime]) ** 2
            ))
            for z in range(dimension)
            for z_prime in range(z)
        )
        delta_approximate = min(
            np.sqrt(np.sum(
                weights
                * (approximate_vectors[z] - approximate_vectors[z_prime]) ** 2
            ))
            for z in range(dimension)
            for z_prime in range(z)
        )
        delta_lower = delta_approximate - np.sqrt(2) * eta
        delta_min_slack = min(delta_min_slack, delta_exact - delta_lower)
        if delta_exact + 1e-9 < delta_lower:
            delta_failures += 1

    return {
        "schema_version": 1,
        "seed": 20260809,
        "trials": trials,
        "Q_bound_failures": q_failures,
        "Q_min_slack": q_min_slack,
        "Delta_bound_failures": delta_failures,
        "Delta_min_slack": delta_min_slack,
    }


if __name__ == "__main__":
    result = run()
    print(json.dumps(result, indent=2))
    if result["Q_bound_failures"] or result["Delta_bound_failures"]:
        raise SystemExit(1)
